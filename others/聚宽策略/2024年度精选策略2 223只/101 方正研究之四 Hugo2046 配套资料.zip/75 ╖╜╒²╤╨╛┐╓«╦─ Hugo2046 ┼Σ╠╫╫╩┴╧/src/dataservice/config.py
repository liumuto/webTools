"""
Author: hugo2046 shen.lan123@gmail.com
Date: 2023-06-20 13:32:49
LastEditors: hugo2046 shen.lan123@gmail.com
LastEditTime: 2023-06-20 13:47:27
Description: 
"""
__all__ = "config"


class Config(object):
    def __init__(self) -> None:
        self.windows_conn_str: str = (
            "mysql+mysqlconnector://root:dacc54e8757706c5@101.132.70.214:3306"
        )
        self.linux_conn_str: str = (
            "mysql+mysqlconnector://root:dacc54e8757706c5@172.19.83.170:3306"
        )


config: Config = Config()
