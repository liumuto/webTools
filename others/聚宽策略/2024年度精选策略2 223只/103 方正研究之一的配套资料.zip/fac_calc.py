'''
    Auther: Yassin
    多因子选股系列一、日内耀眼时刻计算及日内耀眼波动率的计算
'''
from concurrent.futures import ProcessPoolExecutor
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from jqdatasdk import *
import os


def login():
    auth('Name', 'Password')

def get_data(name = '600519.XSHG',begin_date = "2020-01-01 09:30:00", end_date = "2022-01-01 09:30:00"):
    df = get_price(name, start_date = begin_date, end_date = end_date, frequency = '1m', fields=['open','close','low','high','volume','money','pre_close'])
    return df


def my_mean(df):
    '''
        df : pd.DataFrame
        盘中时间的成交量变化的均值
    '''
    return df[df["time_flag"] == True]["vol_change"].mean()



def my_std(df):
    '''
        df : pd.DataFrame
        盘中时间的成交量变化的标准差
    '''
    return df[df["time_flag"] == True]["vol_change"].std()



def solve_flag(time:str = "2022-01-04"):
    time = pd.to_datetime(time)
    Year = time.year
    Month = time.month
    df = pd.read_pickle("E:\datalib\minute_bar\{}\{}\{}.pkl".format(Year, Month, time.strftime("%Y-%m-%d")))


    #根据给定的分钟数据，选出每天的耀眼时刻，即成交量变动大于均值 + 标准差的时刻，将其标注为 spot = True 

    df["time"] = pd.to_datetime(df["time"])

    # 研报中没有给开盘时间和收盘时间的明确定义，这里规定 9:35:00 到 14:55:00 “盘中时间”
    Llmt = pd.to_datetime('09:35:00').time()
    Rlmt = pd.to_datetime('14:55:00').time()

    # 盘中时间标记
    df["time_flag"] = df["time"].apply(lambda x: x.time() > Llmt and x.time() < Rlmt)
    
    # 成交量变化
    df["vol_change"] = df.groupby(["code"])["volume"].diff(axis = 0, periods = 1)
    df["vol_change"].fillna(0, inplace = True)
    g = df.groupby(["code"]).apply(my_mean).to_frame().reset_index(drop = False)
    g.columns = ["code", "vol_mean"]
    df = df.merge(g, on = ["code"], how = "inner")
    g = df.groupby(["code"]).apply(my_std).to_frame().reset_index(drop = False)
    g.columns = ["code", "vol_std"]
    df = df.merge(g, on = ["code"], how = "inner")
    df = df.reset_index(drop = True)

    # df.drop("time_flag", axis = 1, inplace = True)

    # spot 为激增时刻标记，定义为成交量变化大于均值 + 标准差的时刻
    df["spot"] = df["vol_change"] > (df["vol_mean"] + df["vol_std"])
    df["spot"].fillna(False, inplace = True)
    df["spot"] = df["spot"] & df["time_flag"]
    df["spot"] = df["spot"].astype(int)

    # min_ret 为每分钟的收益率
    df["min_ret"] = (df["close"] - df["pre_close"]) / df["pre_close"]

    
    # 日耀眼波动率 = 包括该激增时刻在内五分钟收益率的标准差 
    # vol_5 为从 t-4 开始到 t 时刻的收益率的标准差
    vol_5_last = df.groupby("code", as_index = False).rolling(window = 5)["min_ret"].std()
    vol_5_last= vol_5_last.to_frame().reset_index(drop = False)
    vol_5_last.columns = ["temp1","temp2", "vol_5_last"]
    df["vol_5_last"] = vol_5_last["vol_5_last"]

    df["vol_5"] = df.groupby("code")["vol_5_last"].shift(-4)
    df["vol_5"].fillna(0, inplace = True)
    df.drop("vol_5_last", axis = 1, inplace = True)

    df["vol_spot"] = df["vol_5"] * df["spot"]
    fac1 = df.groupby(["code"], as_index = False)["vol_spot"].mean()
    fac1 = fac1.reset_index(drop = True)
    
    # 这里为了验证，加了一个 spot_count 的计数，可以看到每天的激增时刻的个数
    g = df.groupby(["code"], as_index = False)["spot"].sum()
    g = g.reset_index(drop = True)
    g.columns = ["code", "spot_count"]
    fac1 = fac1.merge(g, on = ["code"], how = "inner")

    # 日耀眼收益率 = 在该激增时刻分钟收益率的均值

    df["ret_spot"] = df["min_ret"] * df["spot"]
    fac2 = df.groupby(["code"], as_index = False)["ret_spot"].mean()
    fac2 = fac2.reset_index(drop = True)
    fac2.columns = ["code", "ret_spot"]

    fac1 = fac1.merge(fac2, on = ["code"], how = "inner")
    fac1["date"] = time.strftime("%Y-%m-%d")
    # print(fac1, fac1["ret_spot"].max(), df["ret_spot"].max())

    name = "fac1"

    # 存储到对应 year/month 的路径下，pickle 格式
    if not os.path.exists("E:\\datalib\\{}".format(name)):
        os.mkdir("E:\\datalib\\{}".format(name))
    if not os.path.exists("E:\\datalib\\{}\\{}".format(name,Year)):
        os.mkdir("E:\\datalib\\{}\\{}".format(name,Year))
    if not os.path.exists("E:\datalib\\{}\{}\{}".format(name,Year, Month)):
        os.mkdir("E:\\datalib\\{}\{}\{}".format(name,Year, Month))

    fac1.to_pickle("E:\datalib\\{}\{}\{}\{}.pkl".format(name,Year, Month, time.strftime("%Y-%m-%d")))

    return


def main():
    login()
    begin_date = "2020-01-01"
    end_date= "2023-04-17"

    trade_cal = get_trade_days(start_date=begin_date, end_date=end_date)
    trade_cal = [_.strftime("%Y-%m-%d") for _ in trade_cal]

    # 用多进程加速
    with ProcessPoolExecutor(max_workers=8) as pool:
        pool.map(solve_flag, trade_cal)


if __name__ == "__main__":
    main()




