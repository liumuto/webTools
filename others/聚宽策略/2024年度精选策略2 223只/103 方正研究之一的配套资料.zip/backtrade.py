import pandas as pd
import numpy as np
import warnings
warnings.filterwarnings("ignore")

def solve_code_for_jq(code:str) -> str:
    '''
        不考虑北交所
        code : str
            600519.SZ
        return : str
            600519.XSHG
    '''

    if code[7] == "S":
        return code[:6] + ".XSHG"
    else:
        return code[:6] + ".XSHE"

def back_trade(df, tar_col) -> pd.DataFrame:

    '''
        月度调仓，按照 tar_col 分十组进行回测
        df : pd.DataFrame
        tar_col : str
            因子列名
        这里不考虑涨停跌停的情况，即假设每天都能买入卖出
        相当于 “合成指数”，并不严谨，毕竟是单因子全市场选股，用一个完整的回测引擎来测有点麻烦了
        TODO：后面会精细一点回测 300 成分股的情况
    '''

    price_df = pd.read_pickle("price_not_fq.pkl")
    price_df["date"] = pd.to_datetime(price_df["trade_date"])
    price_df["code"] = price_df["ts_code"].apply(solve_code_for_jq)
    price_df = price_df[["date", "code", "open", "close", "pre_close"]]


    df.dropna(how = "any", inplace = True)
    df["date"] = pd.to_datetime(df["date"])
    df = pd.merge(df, price_df, on = ["date", "code"], how = 'inner')

    hold_days = 20
    trade_cal = sorted(list(set(df["date"].tolist())))

    ret = [[],[],[],[],[],[],[],[],[],[],[]]
    hold_list = [[],[],[],[],[],[],[],[],[],[],[]]

    for i in range(len(trade_cal)):
        today_df = df[df["date"] == trade_cal[i]]
        if i % 20 == 0:
            # 调仓
            today_df["group"] = pd.qcut(today_df[tar_col], 10, labels = [0,1,2,3,4,5,6,7,8,9])
            for j in range(10):
                tmp_df = today_df[today_df["group"] == j]
                tmp_df["ret"] = (tmp_df["close"] - tmp_df["open"]) / tmp_df["open"]
                ret[j].append(tmp_df["ret"].mean())
                hold_list[j] = tmp_df["code"].tolist()
        else:
            # 不调仓
            for j in range(10):
                tmp_df = today_df[today_df["code"].isin(hold_list[j])]
                tmp_df["ret"] = (tmp_df["close"] - tmp_df["pre_close"]) / tmp_df["pre_close"]
                ret[j].append(tmp_df["ret"].mean())
    
    ret_df = pd.DataFrame()
    ret_df["date"] = trade_cal
    for j in range(0,10):
        ret_df["ret_{}".format(j)] = ret[j]
        ret_df["ret_{}".format(j)] = ret_df["ret_{}".format(j)] + 1
        ret_df["ret_{}".format(j)] = ret_df["ret_{}".format(j)].cumprod()
    # print(ret_df)
    return ret_df                

if __name__ == "__main__":
    fac_df = pd.read_pickle("calced_fac.pkl")
    df = back_trade(fac_df, "fac1")
    print(df)