import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings("ignore")
from concurrent.futures import ProcessPoolExecutor
from jqdatasdk import *
import os


def login():
    auth('Name', 'Password')
    print(get_query_count())

def calc(date):

    def find_max_min(df) -> pd.DataFrame:
        '''
            寻找 vol_9 中最高点的 index 记为 max_pos
            在 max_pos 前寻找一个 vol_9 最小的点记为 min_pos_1
            在 max_pos 后寻找一个 vol_9 最小的点记为 min_pos_2
            最后返回 (min_pos_1, max_pos, min_pos2)
        '''
        this_Llmt = pd.to_datetime('09:40:00').time()
        this_Rlmt = pd.to_datetime('14:50:00').time()
        df["my_time_flag"] = df["time"].apply(lambda x: x.time() >= this_Llmt and x.time() <= this_Rlmt)
        temp_df = df[df["my_time_flag"] == True]
        max_pos = temp_df["vol_9"].idxmax()
        
        df = df[df["time_flag"] == True]
        min_pos_1 = df[df.index < max_pos]["vol_9"].idxmin()
        min_pos_2 = df[df.index > max_pos]["vol_9"].idxmin()
        dic = {
            "code": [df.loc[max_pos, "code"]],
            "min_pos_1": [min_pos_1], 
            "max_pos": [max_pos], 
            "min_pos_2": [min_pos_2], 
            "min_pos_1_vol" : [df.loc[min_pos_1, "vol_9"]], 
            "max_pos_vol" : [df.loc[max_pos, "vol_9"]], 
            "min_pos_2_vol" : [df.loc[min_pos_2, "vol_9"]],
            "min_pos_1_close" : [df.loc[min_pos_1, "close"]],
            "max_pos_close" : [df.loc[max_pos, "close"]],
            "min_pos_2_close" : [df.loc[min_pos_2, "close"]],
            # "min_pos_1_time" : [df.loc[min_pos_1, "time"]],
            # "max_pos_time" : [df.loc[max_pos, "time"]],
            # "min_pos_2_time" : [df.loc[min_pos_2, "time"]],
            }
        return pd.DataFrame(dic)
    

    date = pd.to_datetime(date)

    Month = date.month
    Year = date.year

    df = pd.read_pickle("E:\\datalib\\minute_bar\\{}\\{}\\{}.pkl".format(Year, Month, date.strftime("%Y-%m-%d")))
    df["time"] = pd.to_datetime(df["time"])
    Llmt = pd.to_datetime('09:35:00').time()
    Rlmt = pd.to_datetime('14:55:00').time()
    df["time_flag"] = df["time"].apply(lambda x: x.time() >= Llmt and x.time() <= Rlmt)


    df["vol_9_bef"] = df.groupby("code", as_index = False)["volume"].apply(lambda x: x.rolling(9).sum())
    df["vol_9"] = df.groupby("code", as_index = False)["vol_9_bef"].shift(-4)
    df["vol_9"].fillna(0, inplace = True)
    df.drop("vol_9_bef", axis = 1, inplace = True)

    # 通过 find_max_min 函数找到 涨潮时刻，顶峰时刻和退潮时刻

    tar_col = [
        "code",
        "min_pos_1",
        "max_pos",
        "min_pos_2",
        "min_pos_1_vol",
        "max_pos_vol",
        "min_pos_2_vol",
        "min_pos_1_close",
        "max_pos_close",
        "min_pos_2_close",
        # "min_pos_1_time",
        # "max_pos_time",
        # "min_pos_2_time",
        ]
    
    fac = df.groupby("code", as_index = False).apply(find_max_min).reset_index(drop = False)[tar_col]

    fac["date"] = date.strftime("%Y-%m-%d")

    name = "fac2"
    # 存储到对应 year/month 的路径下，pickle 格式
    if not os.path.exists("E:\\datalib\\{}".format(name)):
        os.mkdir("E:\\datalib\\{}".format(name))
    if not os.path.exists("E:\\datalib\\{}\\{}".format(name,Year)):
        os.mkdir("E:\\datalib\\{}\\{}".format(name,Year))
    if not os.path.exists("E:\datalib\\{}\{}\{}".format(name,Year, Month)):
        os.mkdir("E:\\datalib\\{}\{}\{}".format(name,Year, Month))

    fac.to_pickle("E:\datalib\\{}\{}\{}\{}.pkl".format(name,Year, Month, date.strftime("%Y-%m-%d")))

def main():
    login()
    # calc("2022-01-04")

    begin_date = "2020-01-01"
    end_date= "2023-04-30"

    trade_cal = get_trade_days(start_date=begin_date, end_date=end_date)
    trade_cal = [_.strftime("%Y-%m-%d") for _ in trade_cal]

    # 用多进程加速
    with ProcessPoolExecutor(max_workers=8) as pool:
        pool.map(calc, trade_cal)

if __name__ == "__main__":
    main()


