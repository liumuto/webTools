import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings("ignore")
from concurrent.futures import ProcessPoolExecutor
from jqdatasdk import *
import os


def login():
    auth('Name', 'Password')
    print(get_query_count())

def calc(date):

    def calc_vol(df) -> None:
        '''
            计算 “更优波动率”， 包括 [t-4,t] 共 5 分钟高开低收的 (标准差/均值) ^ 2
        '''
        ret = []

        my_Llmt = pd.to_datetime('09:40:00').time()
        my_Rlmt = pd.to_datetime('14:50:00').time()

        df = df.reset_index(drop = True)
        for i in range(df.shape[0]):
            if df["time_flag"][i] == False:
                ret.append(np.nan)
            else:
                g1 = df["high"][i-4:i+1].values
                g2 = df["low"][i-4:i+1].values
                g3 = df["close"][i-4:i+1].values
                g4 = df["open"][i-4:i+1].values

                g = np.concatenate([g1, g2, g3, g4])
                M = np.mean(g)
                S = np.std(g)
                # print(S, M)
                ret.append((S/M)**2)
        
        # df_L.append(pd.Series(ret, name = "pre_vol"))
        df["pre_vol"] = pd.Series(ret, name = "pre_vol")
        return df

    date = pd.to_datetime(date)

    Month = date.month
    Year = date.year

    df = pd.read_pickle("E:\\datalib\\minute_bar\\{}\\{}\\{}.pkl".format(Year, Month, date.strftime("%Y-%m-%d")))
    df["time"] = pd.to_datetime(df["time"])
    Llmt = pd.to_datetime('09:40:00').time()
    Rlmt = pd.to_datetime('14:50:00').time()
    df["time_flag"] = df["time"].apply(lambda x: x.time() > Llmt and x.time() <= Rlmt)
    df["ret"] = (df["close"] - df["pre_close"]) / df["pre_close"]
    # df_L = []
    df = df.groupby(["code"], as_index = False).apply(calc_vol).reset_index(drop = False)
    df.drop(["level_0", "level_1"], axis = 1, inplace = True)
    # print(df)
    
    # df_L = pd.concat(df_L, axis = 0, ignore_index = True)
    # print(df_L)
    # df["pre_vol"] = df_L

    df["ret_vol_ratio"] = df["ret"] / df["pre_vol"]
    df["ret_vol_ratio"] = df["ret_vol_ratio"].apply(lambda x: np.nan if x == np.inf else x)
    df["ret_vol_ratio"].fillna(0, inplace = True)
    
    # test_df = df[df["code"] == "000001.XSHE"]
    # test_df.to_csv("000001.csv")

    df1 = df[df["time_flag"] == True] 
    fac1 = df1.groupby("code", as_index = False).apply(lambda x: np.cov(x["ret_vol_ratio"], x["ret"])[0,1])
    fac1.columns = ["code", "fac1"]

    Mean1 = df1.groupby("code", as_index = False).apply(lambda x: np.mean(x["pre_vol"]))
    Std1 = df1.groupby("code", as_index = False).apply(lambda x: np.std(x["pre_vol"]))
    
    Mean1.columns = ["code", "Mean1"]
    Std1.columns = ["code", "Std1"]
    
    fac2 = pd.merge(Mean1, Std1, on = "code")
    fac2["M_plus_S"] = fac2["Mean1"] + fac2["Std1"]
    fac2 = fac2[["code", "M_plus_S"]]
    fac2 = pd.merge(df, fac2, on = "code", how = "left")
    fac2 = fac2[fac2["pre_vol"] > fac2["M_plus_S"]]
                
    fac2 = fac2.groupby("code", as_index = False).apply(lambda x: np.cov(x["ret_vol_ratio"], x["ret"])[0,1])
    fac2.columns = ["code", "fac2"]
    fac2.fillna(0, inplace = True)
    
    fac_fin = pd.merge(fac1, fac2, on = "code")
    # fac_fin.to_csv("fac_fin.csv")
    

    print(fac_fin)

    

    name = "fac3"
    # 存储到对应 year/month 的路径下，pickle 格式
    if not os.path.exists("E:\\datalib\\{}".format(name)):
        os.mkdir("E:\\datalib\\{}".format(name))
    if not os.path.exists("E:\\datalib\\{}\\{}".format(name,Year)):
        os.mkdir("E:\\datalib\\{}\\{}".format(name,Year))
    if not os.path.exists("E:\datalib\\{}\{}\{}".format(name,Year, Month)):
        os.mkdir("E:\\datalib\\{}\{}\{}".format(name,Year, Month))

    fac_fin.to_pickle("E:\datalib\\{}\{}\{}\{}.pkl".format(name,Year, Month, date.strftime("%Y-%m-%d")))

def main():
    login()
    # calc("2022-01-04")

    begin_date = "2022-01-01"
    end_date= "2023-05-30"

    trade_cal = get_trade_days(start_date=begin_date, end_date=end_date)
    trade_cal = [_.strftime("%Y-%m-%d") for _ in trade_cal]

    # 用多进程加速
    with ProcessPoolExecutor(max_workers=8) as pool:
        pool.map(calc, trade_cal)

if __name__ == "__main__":
    main()


