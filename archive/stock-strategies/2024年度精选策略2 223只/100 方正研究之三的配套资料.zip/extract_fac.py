import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os
from jqdatasdk import *


def login():
    auth('Name', 'Password')
    print(get_query_count())

def extract_fac(begin_date, end_date, fac_dir = "E:\\datalib\\fac3"):
    
    df_L = []

    trade_cal = get_trade_days(start_date=begin_date, end_date=end_date)

    for date in trade_cal:
        Year = date.year
        Month = date.month
        Path = fac_dir + "\\" + str(Year) + "\\" + str(Month) + "\\" + date.strftime("%Y-%m-%d") + ".pkl"
        df = pd.read_pickle(Path)
        df["date"] = date.strftime("%Y-%m-%d")
        # print(df)
        df_L.append(df)

    fin_df = pd.concat(df_L)
    fin_df = fin_df.reset_index(drop=True)

    return fin_df

if __name__ == "__main__":
    login()
    df = extract_fac("2022-01-01", "2023-04-30")
    print(df)
    df.to_pickle("fac2.pkl")




